package com.example.glassappwidget

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

class LauncherActivity : Activity() {
    companion object {
        const val EXTRA_PACKAGE = "target_package"
        const val EXTRA_LABEL = "target_label"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val packageName = intent.getStringExtra(EXTRA_PACKAGE)
        val label = intent.getStringExtra(EXTRA_LABEL) ?: "Aplikasi"
        if (packageName.isNullOrBlank()) {
            Toast.makeText(this, "Tambahkan GlassApp Widget ke layar utama.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            try {
                startActivity(launchIntent)
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "$label tidak dapat dibuka.", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "$label belum terpasang atau package ID berbeda.", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=${Uri.encode(label)}&c=apps")))
            } catch (_: Exception) { }
        }
        finish()
    }
}
