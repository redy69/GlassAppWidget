package com.example.glassappwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.widget.RemoteViews

class GlassWidgetProvider : AppWidgetProvider() {
    data class AppEntry(
        val key: String,
        val label: String,
        val packages: List<String>,
        val iconView: Int,
        val labelView: Int,
        val tileView: Int
    )

    private val entries = listOf(
        AppEntry("chatgpt", "ChatGPT", listOf("com.openai.chatgpt"), R.id.icon_chatgpt, R.id.label_chatgpt, R.id.tile_chatgpt),
        AppEntry("gemini", "Gemini", listOf("com.google.android.apps.bard", "com.google.android.googlequicksearchbox"), R.id.icon_gemini, R.id.label_gemini, R.id.tile_gemini),
        AppEntry("mt", "MT Manager", listOf("bin.mt.plus"), R.id.icon_mt, R.id.label_mt, R.id.tile_mt),
        AppEntry("apktool", "Apktool M", listOf("ru.maximoff.apktool", "ru.maximoff.apktoolm"), R.id.icon_apktool, R.id.label_apktool, R.id.tile_apktool)
    )

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> updateOne(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == Intent.ACTION_PACKAGE_ADDED || intent.action == Intent.ACTION_PACKAGE_REMOVED || intent.action == Intent.ACTION_PACKAGE_CHANGED) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, GlassWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }
    }

    private fun updateOne(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_glass)
        val pm = context.packageManager
        entries.forEach { entry ->
            val installedPackage = entry.packages.firstOrNull { packageName ->
                try { pm.getApplicationInfo(packageName, 0); true } catch (_: Exception) { false }
            }
            if (installedPackage != null) {
                try {
                    val drawable = pm.getApplicationIcon(installedPackage)
                    views.setImageViewBitmap(entry.iconView, drawable.toBitmap())
                } catch (_: Exception) {
                    views.setImageViewResource(entry.iconView, R.drawable.ic_glass_widget)
                }
            } else {
                views.setImageViewResource(entry.iconView, R.drawable.ic_glass_widget)
            }
            views.setTextViewText(entry.labelView, entry.label)
            val clickIntent = Intent(context, LauncherActivity::class.java).apply {
                putExtra(LauncherActivity.EXTRA_PACKAGE, installedPackage ?: entry.packages.first())
                putExtra(LauncherActivity.EXTRA_LABEL, entry.label)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pending = PendingIntent.getActivity(
                context,
                widgetId * 10 + entries.indexOf(entry),
                clickIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(entry.tileView, pending)
        }
        manager.updateAppWidget(widgetId, views)
    }

    private fun Drawable.toBitmap(): Bitmap {
        val width = intrinsicWidth.coerceAtLeast(1)
        val height = intrinsicHeight.coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        setBounds(0, 0, canvas.width, canvas.height)
        draw(canvas)
        return bitmap
    }
}
