# Build APK langsung dari HP (tanpa Android Studio)

Project ini sudah dilengkapi GitHub Actions untuk membangun APK secara online.

1. Ekstrak ZIP ini, lalu unggah **isi folder `GlassAppWidget`** ke repository GitHub baru.
2. Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
3. Buka tab **Actions** di repository GitHub.
4. Pilih **Build GlassAppWidget APK** lalu tekan **Run workflow** (atau tunggu build otomatis setelah push ke branch `main`).
5. Setelah status workflow hijau, buka hasil run tersebut.
6. Di bagian **Artifacts**, unduh `GlassAppWidget-debug-apk`.
7. Ekstrak ZIP artifact dan pasang `app-debug.apk` di HP. Jika diminta, izinkan instalasi dari sumber tersebut.

Catatan: GitHub memerlukan akun dan repository. APK debug ini ditandatangani dengan debug key otomatis dan cocok untuk uji coba pribadi, bukan distribusi Play Store.
