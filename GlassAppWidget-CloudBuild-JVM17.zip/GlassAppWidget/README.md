# GlassApp Widget

Widget Android Home Screen bergaya glassmorphism dengan empat shortcut: ChatGPT, Gemini, MT Manager, dan Apktool M.

## Fitur
- Layout horizontal: panel informasi di kiri, shortcut 2x2 di kanan.
- Bingkai putih tipis, sudut membulat, dan latar semi-transparan.
- Mengambil ikon asli aplikasi dari PackageManager jika aplikasi terpasang.
- Menekan tile akan membuka aplikasi target.
- Jika aplikasi belum ditemukan, widget menampilkan pemberitahuan dan membuka pencarian Google Play.
- Bisa diubah ukuran (resize) pada launcher yang mendukung.

## Build di Android Studio
1. Ekstrak ZIP.
2. Buka folder `GlassAppWidget` melalui Android Studio.
3. Tunggu Gradle Sync dan izinkan Android Studio mengunduh Gradle 8.9 serta Android Gradle Plugin 8.7.3 jika diminta.
4. Pastikan Android SDK Platform 35 terpasang (SDK Manager).
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Pasang widget
1. Install APK hasil build.
2. Tekan lama area kosong di Home Screen.
3. Buka menu **Widgets**.
4. Cari **GlassApp Widget**, lalu seret ke Home Screen.
5. Ubah ukuran widget jika diperlukan.

## Package ID yang digunakan
- ChatGPT: `com.openai.chatgpt`
- Gemini: `com.google.android.apps.bard` (fallback pencarian aplikasi Google: `com.google.android.googlequicksearchbox`)
- MT Manager: `bin.mt.plus`
- Apktool M: `ru.maximoff.apktool` (fallback: `ru.maximoff.apktoolm`)

Nama package beberapa aplikasi pihak ketiga dapat berbeda antarversi/distribusi. Jika tile tidak membuka aplikasi, periksa package ID melalui MT Manager atau detail APK, lalu ubah daftar `packages` di `GlassWidgetProvider.kt` dan daftar `<queries>` di `AndroidManifest.xml`.

## Catatan tampilan
Android AppWidget memakai RemoteViews, sehingga efek blur real-time seperti kaca sistem tidak tersedia secara universal. Project ini menggunakan panel putih semi-transparan dan outline sebagai pendekatan kompatibel.

## Kompatibilitas
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- Bahasa: Kotlin
- UI widget: XML + RemoteViews
